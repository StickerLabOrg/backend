from sqlalchemy.orm import Session
from src.usuario.models.user import User

def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()

def create_user(db: Session, nome: str, email: str, password_hash: str, time_do_coracao: str, is_admin=False):
    user = User(
        nome=nome,
        email=email,
        password_hash=password_hash,
        time_do_coracao=time_do_coracao,
        is_admin=is_admin
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
