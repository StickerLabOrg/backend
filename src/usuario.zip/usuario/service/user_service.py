from passlib.context import CryptContext
from datetime import timedelta, datetime
from jose import jwt
from src.config import settings
from src.usuario.repository.user_repository import get_user_by_email, create_user

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

from typing import Optional

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    return encoded_jwt

def register_user(db, nome: str, email: str, password: str, time_do_coracao: str):
    existing = get_user_by_email(db, email)
    if existing:
        raise ValueError("E-mail já cadastrado.")
    hashed = get_password_hash(password)
    return create_user(db, nome, email, hashed, time_do_coracao)

def login_user(db, email: str, password: str):
    user = get_user_by_email(db, email)
    if not user or not verify_password(password, user.password_hash):
        raise ValueError("Credenciais inválidas.")
    access_token = create_access_token({"sub": str(user.id)})
    return {"access_token": access_token, "token_type": "bearer"}
