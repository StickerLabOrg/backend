from pydantic import BaseModel

class UserRegister(BaseModel):
    nome: str
    email: str
    password: str
    time_do_coracao: str


class UserResponse(BaseModel):
    id: int
    nome: str
    email: str
    time_do_coracao: str
    coins: int

    class Config:
        orm_mode = True
